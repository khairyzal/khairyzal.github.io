import {setSwagger,UIData} from './swaggerfunction.js';

window.ui = UIData;
window.onload = setSwagger();
