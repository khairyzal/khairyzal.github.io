import { get } from "https://jscroot.github.io/api/croot.js";
import {setInner,addChild } from "https://jscroot.github.io/element/croot.js";
import {URLGeoJson,responseData} from "./getfunction.js";

get(URLGeoJson,responseData);